//
//  BreedTableViewCell.swift
//  DogBreedsApp
//
//  Created by Kovid Behl on 2024-08-14.
//

import UIKit

class BreedTableViewCell: UITableViewCell {
    @IBOutlet weak var breedImageView: UIImageView!
    @IBOutlet weak var breedNameLabel: UILabel!
}
