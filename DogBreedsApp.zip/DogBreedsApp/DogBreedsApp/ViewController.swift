//
//  ViewController.swift
//  DogBreedsApp
//
//  Created by Kovid Behl on 2024-08-14.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

