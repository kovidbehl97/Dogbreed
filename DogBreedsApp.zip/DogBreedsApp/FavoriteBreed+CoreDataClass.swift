//
//  FavoriteBreed+CoreDataClass.swift
//  DogBreedsApp
//
//  Created by Kovid Behl on 2024-08-14.
//
//

import Foundation
import CoreData

@objc(FavoriteBreed)
public class FavoriteBreed: NSManagedObject {

}
